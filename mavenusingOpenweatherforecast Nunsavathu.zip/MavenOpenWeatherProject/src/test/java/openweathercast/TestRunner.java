package openweathercast;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		format={"pretty"},
		features="C:/Users/Chavana Jayakrishna/workspace/MavenSampleProject/src/test/resource")

public class TestRunner {

}
