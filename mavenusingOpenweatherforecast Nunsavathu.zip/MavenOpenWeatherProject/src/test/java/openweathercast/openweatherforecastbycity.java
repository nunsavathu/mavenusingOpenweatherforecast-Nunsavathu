package openweathercast;

import org.openqa.selenium.By;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class openweatherforecastbycity extends Browsersetup {
	
	private String URL = "http://openweathermap.org/forecast5";
	
	

@Given("^I am on the Openweathermap home page$")
public void i_am_on_the_Openweathermap_home_page() throws Throwable {
	 setUp();
	driver.get(URL);
}

@When("^I click on \"(.*?)\" in homepage$")
public void i_click_on_in_homepage(String weather) throws Throwable {
	driver.findElement(By.id(weather)).click();
}

@When("^I enter \"(.*?)\" in the search box$")
public void i_enter_in_the_search_box(String Cityname) throws Throwable {
   driver.findElement(By.name("q")).sendKeys(Cityname);
}

@Then("^I click on search box to get the forecast of the city$")
public void i_click_on_search_box_to_get_the_forecast_of_the_city() throws Throwable {
   driver.findElement(By.className("btn btn-default")).click();   
}


@Given("^I click on \"(.*?)\" to get the daily forecast$")
public void i_click_on_to_get_the_daily_forecast(String cityname) throws Throwable {
       driver.findElement(By.partialLinkText(cityname)).click();
}

@When("^I click on hourly to get the forecast$")
public void i_click_on_hourly_to_get_the_forecast() throws Throwable {
	driver.findElement(By.id("hourly_list_a")).click();

}

@When("^I click on daily weather forecast$")
public void i_click_on_daily_weather_forecast() throws Throwable {
  driver.findElement((By.id("daily_chart_a"))).click();
}

@Then("^I summarise the (\\d+) hour data$")
public void i_summarise_the_hour_data(int arg1) throws Throwable {
driver.findElement(By.id("forecast-chart_a")).click();
driver.findElement(By.id("temp")).click();
driver.findElement(By.id("wind")).click();
driver.findElement(By.xpath("//a[contains(@id,'pressure')]")).click();
driver.findElement(By.id("precipitation")).click();
}


}
