package openweathercast;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Browsersetup {
	
	WebDriver driver;
	

	public void setUp(){
		driver =new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	
	}
	

	public void driverClose(){
		driver.close();
	}

}
